LEAD MAGNET PDF — PAGE 8 UPSELL BLOCK (Vol.3)
Headline: SYSTEM_UPDATE_AVAILABLE
Body: You located the bottleneck. The Deep Work Daemon is the 50-question patch script that isolates the distraction loop (notifications → scroll → guilt → avoidance) and forces a clean firewall rule + recovery ritual.
CTA: Get the Deep Work Daemon ($29)
Downsell line (optional): Prefer to start light? Re-run the Focus Status Check weekly for calibration.
