CHECKOUT BULLETS (7)
- 50 clinical-grade questions (I2–I3 intensity cap, self-paced safe)
- 4-block arc: START → DEEP → ACTION → CLOSE
- Data-first response format (not “journaling”)
- Loop map: identify the exact distraction script running you
- Firewall rules: notification + app + tab + scroll constraints
- Analog recovery: low-dopamine restoration actions
- Print-friendly, high-contrast PDF (v1.1)
