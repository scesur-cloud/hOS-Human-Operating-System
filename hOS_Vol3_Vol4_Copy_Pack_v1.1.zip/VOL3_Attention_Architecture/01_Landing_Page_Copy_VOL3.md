LANDING PAGE COPY // hOS v1.1
PRODUCT: DEEP_WORK_DAEMON // Attention Architecture (Vol.3)
DATE: 2025-12-14

1) HERO (Above the fold)
Headline: Debug Your Attention Architecture.
Sub-headline: You don’t need “more discipline.” You need a clean memory model. Run a 50-question deep-dive that isolates your specific distraction loop — Hardware, OS, Network, or Output — and generates a practical firewall.
Primary CTA Button: [ GET THE DEEP WORK DAEMON ($29) ]
CTA Subtext: Instant PDF Download • v1.1 • Self-Paced • High-contrast / print-friendly
Downsell link (under CTA): Not ready for the full protocol? [Run the free Focus Status Check first.]

2) THE PROBLEM (Agitation)
Header: Stop blaming yourself for a corrupted RAM.
Body:
Your tools are faster than ever — and your attention is weaker than ever.
You context-switch, you scroll, you “research,” you optimize workflows… and your real work never lands.
That’s not a character flaw. It’s a system error:
- Input Noise: notifications + feeds triggering threat/novelty reflexes
- OS Loops: boredom intolerance + perfectionism + “certainty addiction” before starting
- Output Leakage: busywork disguised as progress

The Reality: “Focus” isn’t a vibe. It’s an architecture.

3) THE SOLUTION (What You Get)
Header: The Deep Work Daemon (50Q)
Body:
A clinical-grade debugging script designed for creatives, remote workers, and solopreneurs.
No fluff. No inspirational quotes. Just profiling + refactoring.

The 4-Block Arc:
BLOCK I: START (Input Log) — 10 Questions
- Screen reality check, sensory overload, sleep/stimulant signatures.
BLOCK II: DEEP (The Glitch) — 28 Questions
- What emotion you’re numbing (boredom vs anxiety), tool-hopping, perfectionism, control scripts.
BLOCK III: ACTION (The Firewall) — 9 Questions
- Notification policy, deep-work rules, tab/scroll constraints.
BLOCK IV: CLOSE (Analog Mode) — 3 Questions
- Low-dopamine recovery and one “lever” that restores clarity.

Runtime: 45–60 minutes.
Output: One bottleneck + one concrete boundary + one recovery ritual.

4) MINI-OUTPUT LIST (Conversion booster)
Header: What you will have in 60 minutes:
1. The Root Cause: You’ll know if the drag is Biological (sleep/sensory), Psychological (control/perfectionism), or Behavioral (scroll loops).
2. The Loop Map: You’ll see the exact script (e.g., boredom → phone → guilt → avoidance → overload).
3. The Patch: One rule you will enforce and one recovery action you will schedule.

5) OFFER STACK + JUSTIFICATION
Header: Why this isn’t “another PDF.”
✅ Clinical-Grade Architecture: Hardware → OS → Output (biology-first).
✅ Data > Story: “I’m distracted” becomes measurable inputs (time, apps, triggers).
✅ Self-Paced Safe: Intensity capped at I2–I3. Includes Stop Rules.
✅ Loop Isolation: You locate the exact app/behavior that leaks bandwidth.

The Investment: $29 (less than the cost of a convenience binge you didn’t enjoy).

6) RISK REVERSAL (No-BS guarantee)
Header: The “Do The Work” Guarantee.
Body:
If you answer all 50 questions honestly and follow the execution rules, but you fail to find a single actionable bottleneck or patch, email us for a refund. No drama. No interrogation.

7) WHO THIS IS NOT FOR (Anti-persona)
Header: Who this is NOT for.
❌ Passive consumers who collect PDFs.
❌ People seeking a magic pill without boundary enforcement.
❌ Acute clinical crisis (daily panic, self-harm). Seek qualified professional support.

8) FAQ
Q: Is this therapy?
A: No. Educational self-audit + behavior design tool.

Q: Can I do it in one sitting?
A: Yes — ideally offline from Slack/email.

Q: Format?
A: High-contrast, print-friendly PDF. Minimal design. Maximum signal.

9) FINAL CTA
Headline: Deploy a firewall for your attention.
CTA Button: [ DOWNLOAD THE DEEP WORK DAEMON ($29) ]
Footer disclaimer: Educational use only. Not medical advice or diagnosis.
