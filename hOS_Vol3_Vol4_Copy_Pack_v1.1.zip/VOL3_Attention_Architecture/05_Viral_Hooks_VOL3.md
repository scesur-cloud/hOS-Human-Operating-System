VIRAL HOOKS (5) — Reels/Shorts/TikTok
1) “If you have 40 tabs open, you’re not multitasking. You’re running anxiety as a browser.”
2) “You don’t need more discipline. You need fewer notifications and a better sleep architecture.”
3) “If ‘research’ makes you feel safe, it might be avoidance disguised as intelligence.”
4) “Your phone isn’t stealing your time. It’s stealing your emotional regulation.”
5) “If boredom feels unbearable, your dopamine baseline is hijacked. Let’s debug that.”
