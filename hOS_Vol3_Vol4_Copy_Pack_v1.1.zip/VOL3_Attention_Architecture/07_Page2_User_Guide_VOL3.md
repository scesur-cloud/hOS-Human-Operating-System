PAID PDF — PAGE 2: PROTOCOL INSTRUCTIONS (Vol.3)
HEADER: PROTOCOL_03 // USER_GUIDE
SUBHEADER: Execution parameters for the Attention Architecture deep-dive.

1) THE FRAME
You are not here to “feel inspired.” You are here to locate the exact loop (inputs, beliefs, behaviors) that corrupts focus.
Total Runtime: ~45–60 minutes
Requirement: Single-task. Treat this like a production deployment.

2) THE SEQUENCE (4 BLOCKS)
BLOCK I: START (Q1–10) // INPUT LOG
Focus: sleep/stimulants, sensory overload, screen reality check.
Why: you can’t out-think a nervous system in overload.

BLOCK II: DEEP (Q11–38) // THE GLITCH
Focus: boredom intolerance, perfectionism, control scripts, tool-hopping.
Why: the loop lives at OS-level.

BLOCK III: ACTION (Q39–47) // THE FIREWALL
Focus: enforceable boundaries (notifications, apps, tabs, timeboxes).
Why: insight without a boundary is entertainment.

BLOCK IV: CLOSE (Q48–50) // ANALOG MODE
Focus: low-dopamine recovery rituals.
Why: you can’t “optimize” forever; you must restore.

3) EXECUTION RULES
- The “5% More” Rule: write the 5% truer sentence you’re avoiding.
- Data > Story: replace labels with metrics (minutes, counts, specific triggers).
- Stop Rule: if you feel acute panic or dissociation, stop and do regulation (walk, water, breath, sunlight). Resume later.
