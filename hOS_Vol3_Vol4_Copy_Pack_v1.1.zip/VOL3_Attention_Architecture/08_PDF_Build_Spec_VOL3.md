PDF BUILD SPEC (Vol.3) — Deep Work Daemon
Format: 10–12 page PDF, high-contrast “technical manual” style.

Page 1 — Cover
Title: DEEP_WORK_DAEMON // hOS v1.1
Subtitle: A 50-question debugging script for your attention architecture.
Visual: abstract wireframe / schematic grid.

Page 2 — User Guide
Use the PROTOCOL_03 // USER_GUIDE text (provided).

Pages 3–8 — The Protocol (50 Questions)
Layout: Tables grouped by Section_Block (START/DEEP/ACTION/CLOSE)
Each row: [Tag] Question → Data Point line.

Page 9 — Diagnostic (Scoring)
Bottleneck rules: Hardware vs OS vs Output + suggested “Firewall Patch” per bottleneck.

Page 10 — Bridge / Upsell
“SYSTEM_UPDATE_AVAILABLE” to the next volume or bundle (Full Stack Audit).
Include stop-rule reminder + disclaimer.
