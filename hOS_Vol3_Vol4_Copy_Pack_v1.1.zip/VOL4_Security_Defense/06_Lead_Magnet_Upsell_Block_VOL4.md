LEAD MAGNET PDF — PAGE 8 UPSELL BLOCK (Vol.4)
Headline: SYSTEM_UPDATE_AVAILABLE
Body: You identified your ego-defense bottleneck. The Shadow Kernel Protocol is the 50-question patch script that maps trigger → defense → damage and installs a repair sentence + boundary sentence you can deploy immediately.
CTA: Get the Shadow Kernel Protocol ($29)
