CHECKOUT BULLETS (7)
- 50 clinical-grade questions (I2–I3 intensity cap, self-paced safe)
- 4-block arc: START → DEEP → ACTION → CLOSE
- Threat-response first (body + conflict tells)
- Projection & defense mapping (root-cause clarity)
- Repair script + boundary sentence (deployable this week)
- Feedback tolerance + “I don’t know” practice
- Print-friendly, high-contrast PDF (v1.1)
