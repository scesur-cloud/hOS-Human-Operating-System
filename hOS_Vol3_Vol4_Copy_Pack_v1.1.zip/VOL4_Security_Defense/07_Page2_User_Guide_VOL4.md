PAID PDF — PAGE 2: PROTOCOL INSTRUCTIONS (Vol.4)
HEADER: PROTOCOL_04 // USER_GUIDE
SUBHEADER: Execution parameters for the Shadow Kernel deep-dive.

1) THE FRAME
You are not here to “be nicer.” You are here to locate the exact defense pattern that activates under threat.
Total Runtime: ~45–60 minutes
Depth: High (kernel-level drivers: shame, control, projection)
Requirement: Single-task. Treat this like a production deployment.

2) THE SEQUENCE (4 BLOCKS)
BLOCK I: START (Q1–10) // THE SHIELD
Focus: irritability, judgment, conflict style, somatic threat tells.
Why: the body reveals threat before the mind admits it.

BLOCK II: DEEP (Q11–38) // THE VAULT
Focus: projection, envy, shame scripts, identity fusion, power narratives.
Why: your defense is built to keep these out of awareness.

BLOCK III: ACTION (Q39–47) // DISARMING
Focus: repair scripts, boundaries, feedback tolerance, “I don’t know” practice.
Why: insight without repair is just self-critique.

BLOCK IV: CLOSE (Q48–50) // INTEGRATION
Focus: highest-leverage pattern + toolkit + safe repair person.
Why: we don’t leave the system open.

3) EXECUTION RULES
- The “5% More” Rule: write the 5% truer sentence you’re avoiding.
- Data > Story: replace labels with observable behaviors (what you did, said, avoided).
- Stop Rule: if you feel acute panic/dissociation, stop and regulate (breath, walk, water). Resume later.
