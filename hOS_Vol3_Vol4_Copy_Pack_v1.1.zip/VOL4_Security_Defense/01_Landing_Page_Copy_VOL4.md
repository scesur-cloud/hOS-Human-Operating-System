LANDING PAGE COPY // hOS v1.1
PRODUCT: SHADOW_KERNEL_PROTOCOL // Security & Defense (Vol.4)
DATE: 2025-12-14

1) HERO (Above the fold)
Headline: Debug Your Defense Mechanisms.
Sub-headline: Your biggest competitor isn’t the market. It’s the scripts you run under threat — control, projection, perfectionism, withdrawal. Run a 50-question protocol that exposes the defense and installs a safer response.
Primary CTA Button: [ GET THE SHADOW KERNEL PROTOCOL ($29) ]
CTA Subtext: Instant PDF Download • v1.1 • Self-Paced • High-contrast / print-friendly
Downsell link: Not ready for the full protocol? [Run the free Ego Status Check first.]

2) THE PROBLEM (Agitation)
Header: Stop calling it “personality.” It’s a defense.
Body:
Under pressure, most leaders don’t become “worse” — they become automated.
- Judgment becomes a shield.
- Certainty becomes addiction.
- Control becomes the drug.
- Conflict becomes a threat response.

Burnout is a stability failure.
Shadow is a security failure.

3) THE SOLUTION (What You Get)
Header: The Shadow Kernel Protocol (50Q)
Body:
A clinical-grade inquiry tool for executives, people managers, and high achievers.
It isolates your defense patterns, your relational damage profile, and the trigger that flips your nervous system into threat mode.

The 4-Block Arc:
BLOCK I: START (The Shield) — 10 Questions
- Irritability, judgment, conflict style, somatic threat tells.
BLOCK II: DEEP (The Vault) — 28 Questions
- Projection, envy, shame scripts, identity fusion, power narratives.
BLOCK III: ACTION (Disarming) — 9 Questions
- Repair scripts, boundary enforcement, feedback tolerance, “I don’t know” practice.
BLOCK IV: CLOSE (Integration) — 3 Questions
- Your highest-leverage pattern + your toolkit + your safe repair person.

Runtime: 45–60 minutes.
Output: One shadow pattern + one repair script + one behavioral disarm.

4) MINI-OUTPUT LIST
Header: What you will have in 60 minutes:
1. The Shield: your default defense under threat (control, anger, intellect, withdrawal).
2. The Trigger Map: what flips you into threat mode and how it shows up in your body.
3. The Patch: one repair sentence + one boundary sentence you will deploy this week.

5) OFFER STACK + JUSTIFICATION
Header: Why this isn’t “shadow work fluff.”
✅ Structured: Hardware → OS → Network → Output (threat response first).
✅ Clinical-grade: defense mechanisms + projection mapping + repair mechanics.
✅ Self-paced safe: intensity capped (I2–I3). Stop Rules included.
✅ Actionable: forces a repair script and a boundary sentence (not vibes).

The Investment: $29 (cheaper than one conflict you’ll regret).

6) RISK REVERSAL
Header: The “Do The Work” Guarantee.
Body:
If you complete the protocol honestly and find zero actionable insight (no trigger, no defense, no patch), email for a refund. No questions asked.

7) WHO THIS IS NOT FOR
❌ People who want comfort, not truth.
❌ People who punish honesty with self-attack.
❌ Acute crisis (self-harm, daily panic). Seek immediate professional support.

8) FAQ
Q: Is this therapy?
A: No. Educational self-audit. Not medical advice.

Q: Will this be uncomfortable?
A: Yes. That’s the point. We keep it self-paced and capped in intensity.

Q: Format?
A: Minimal, high-contrast PDF. Print-friendly.

9) FINAL CTA
Headline: Disarm the defense. Protect the system.
CTA Button: [ DOWNLOAD THE SHADOW KERNEL PROTOCOL ($29) ]
Footer disclaimer: Educational use only. Not medical advice or diagnosis.
