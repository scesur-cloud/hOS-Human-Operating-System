PDF BUILD SPEC (Vol.4) — Shadow Kernel Protocol
Format: 10–12 page PDF, high-contrast “technical manual” style.

Page 1 — Cover
Title: SHADOW_KERNEL_PROTOCOL // hOS v1.1
Subtitle: A 50-question security audit for your defenses under threat.

Page 2 — User Guide
Use PROTOCOL_04 // USER_GUIDE (provided).

Pages 3–8 — The Protocol (50 Questions)
Layout: tables grouped by Section_Block (START/DEEP/ACTION/CLOSE).
Each row: [Tag] Question → Data Point line.

Page 9 — Diagnostic
Identify dominant defense (control/projection/perfectionism/withdrawal) + suggested “Disarm Patch”.

Page 10 — Bridge / Upsell
“SYSTEM_UPDATE_AVAILABLE” (bundle or next volume).
Include stop-rule reminder + disclaimer.
