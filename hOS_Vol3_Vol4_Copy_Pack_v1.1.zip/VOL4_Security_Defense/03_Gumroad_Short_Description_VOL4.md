GUMROAD SHORT DESCRIPTION (1 paragraph)
The Shadow Kernel Protocol is a clinical-grade, self-paced debugging script for your defenses under threat. In 45–60 minutes, it profiles your trigger → defense → damage loop (control, projection, perfectionism, withdrawal), then forces a clean patch: a repair script, a boundary sentence, and an integration toolkit. High-contrast PDF. No fluff.
